//
//  OndemandSDK.h
//  OndemandSDK
//
//  Created by Ishita Agarwal on 16/12/19.
//  Copyright © 2019 DMI. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WexerContentSDK.


FOUNDATION_EXPORT double WexerContentSDKVersionNumber;

//! Project version string for WexerContentSDK.
FOUNDATION_EXPORT const unsigned char WexerContentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OndemandSDK/PublicHeader.h>


